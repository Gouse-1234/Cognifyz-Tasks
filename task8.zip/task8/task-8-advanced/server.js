const express = require("express");
const Redis = require("redis");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const bodyParser = require("body-parser");
const cors = require("cors");
const { orderQueue } = require("./queue");

const app = express();
const PORT = 5000;

// Redis client setup
const redisClient = Redis.createClient({
  legacyMode: true, // important fix for compatibility
});
redisClient.connect().catch(console.error);

// Middleware
app.use(cors());
app.use(morgan("dev"));
app.use(bodyParser.json());
app.use(express.static("public"));

// Rate limiter
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
});
app.use(limiter);

// Dummy product list
const products = [
  { id: 1, name: "Smartphone", price: 699 },
  { id: 2, name: "Laptop", price: 999 },
  { id: 3, name: "Headphones", price: 199 }
];

// API: Get products (with Redis cache)
app.get("/api/products", async (req, res) => {
  try {
    redisClient.get("products", (err, cachedData) => {
      if (err) {
        return res.status(500).json({ error: "Redis error", details: err.message });
      }

      if (cachedData) {
        return res.json({ source: "cache", data: JSON.parse(cachedData) });
      } else {
        redisClient.setex("products", 60, JSON.stringify(products));
        return res.json({ source: "server", data: products });
      }
    });
  } catch (error) {
    res.status(500).json({ error: "Server error", details: error.message });
  }
});

// API: Place order and add job to queue
app.post("/api/order", async (req, res) => {
  const { productId, email } = req.body;

  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: "Product not found" });

  await orderQueue.add("sendOrder", { email, product });
  res.json({ message: `✅ Order received! Email will be sent to ${email}` });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
