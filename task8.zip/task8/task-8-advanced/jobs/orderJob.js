async function handleOrderJob(data) {
  const { email, product } = data;
  console.log("📩 Emailing...");
  console.log(`To: ${email}`);
  console.log(`Product: ${product.name}, ₹${product.price}`);
  console.log("✅ Email sent (simulated)!");
}

module.exports = { handleOrderJob };
