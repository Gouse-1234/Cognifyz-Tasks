const Bull = require("bull");
const { handleOrderJob } = require("./jobs/orderJob");

const orderQueue = new Bull("orderQueue", {
  redis: { host: "127.0.0.1", port: 6379 },
});

orderQueue.process("sendOrder", async (job) => {
  await handleOrderJob(job.data);
});

module.exports = { orderQueue };
